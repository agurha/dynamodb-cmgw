#!/bin/sh

/usr/bin/python3 /home/ubuntu/gazip-master/lambda_function_2.py >>/home/ubuntu/gaziplog.txt 2>&1
/usr/bin/python3 /home/ubuntu/gazip-master/LeadTimesUS.py >>/home/ubuntu/leadtimelogUS.txt 2>&1
/usr/bin/python3 /home/ubuntu/gazip-master/LeadTimesChina.py >>/home/ubuntu/leadtimelogChina.txt 2>&1
