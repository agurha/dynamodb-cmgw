import json
import boto3
import requests
from bs4 import BeautifulSoup
import datetime
import time
import os
import urllib
import re
import urllib3
from io import StringIO
import pandas as pd
from sqlalchemy import create_engine, MetaData, Table, Column, Integer, Float, String
from sqlalchemy.orm import sessionmaker

def buildProductIDs():
    headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36'}
    resp = requests.get("https://web.archive.org/web/20190212080456/https://www.gazelle.com/iphone", headers = headers)
    st = resp.text
    soup = BeautifulSoup(st,'html.parser')
    elm = soup.find_all("script",attrs={"data-js-react-on-rails-store":"DeviceFlowStore"})[0]
    txt = re.subn('<script data-js-react-on-rails-store="DeviceFlowStore" type="application/json">','',str(elm))[0]
    txt = re.subn('</script>','',txt)[0].strip()
    data = json.loads(txt)
    output = {}
    for item in data['deviceFlowData']['deviceFlow']['items']:
        for itm in item['items']:
            for pdt in itm['products']:
                output[pdt['id']] = {'name':pdt['name'],'offerURL':pdt['getOfferUrl']}
    return output

def calculateTradeInPrices():
    data = buildProductIDs()
    timestamp = '20190212080456';
    output = []
    i=0
    for id in data:
        print(id, data[id]['name'], data[id]['offerURL'])
        headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36'}
        url = 'https://web.archive.org/web/20190212080456/https://www.gazelle.com'+data[id]['offerURL'].strip()
        resp = requests.get(url, headers = headers)
        soup= BeautifulSoup(resp.text, 'html.parser')
        quesAns = {}
        elm = soup.find_all('script',attrs={'data-component-name':"GetOfferWrapper"})[0]
        txt = re.subn('</script','',''.join(re.split('>',str(elm))[1:]))[0].strip()
        for ques in json.loads(txt)['initState']['questions']:
            resp = ques['defaultResponse'] if not ques['defaultResponse'] is None else ques['response']
            quesAns["calculator_answers["+ques['id']+"]"]=resp
        time.sleep(2)
        url = 'https://web.archive.org/web/20190212080456/https://www.gazelle.com/products/'+str(id)+'/calculation.json?product_id='+str(id)+'&'+urllib.parse.urlencode(quesAns)
        headers = {'Referer':'https://web.archive.org/web/20190212080456/https://www.gazelle.com'+data[id]['offerURL'].strip(), 
                'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36'}
        resp = requests.get(url, headers = headers)
        temp = json.loads(resp.text)['product']
        output.append({'name':temp['name'],'model':temp['model'],'size':temp['size'],'network':temp['network'],'price':temp['price'], 'timestamp':timestamp})
        time.sleep(2)
        i+=1
        if i > 1:
            break
    return output

    #def lambda_handler(event, context):
    # TODO implement
def lambdaFunction(): 
    output = calculateTradeInPrices()
    #string = json.dumps(output)
    #encoded_string = string.encode("utf-8")
    bucket_name = "gazellep"
    file_name = "gazelle_iPhone_tradein_prices_"+"20190212080456.csv"
    lambda_path = "/tmp/" + file_name
    s3_path = file_name

    json_output = pd.DataFrame(output)
    #json_output['timestamp'] = datetime.datetime.today().isoformat()

    #s3 = boto3.resource("s3")
    csv_buffer = StringIO()
    json_output.to_csv(filename, encoding='utf-8', index=False)
    
    #s3.Bucket(bucket_name).put_object(Key=s3_path, Body=csv_buffer.getvalue())
    
    # create sqlalchemy engine
    #engine = create_engine("mysql+pymysql://{user}:{pw}@database-1.cx7tfzrnpatm.us-east-2.rds.amazonaws.com:3306/{db}"
    #                   .format(user = "admin",
     #                          pw = "new_password",
      #                         db = "gazelle"))
    #metadata = MetaData()
    #table = Table('iPhoneTradeIn', metadata, Column('ID', Integer), Column('name', String), Column('model', String), Column('size', String), Column('network', String), Column('price', Float), Column('timestamp', String))
    #Session = sessionmaker(bind = engine)
    #session = Session()
    #last_index = session.query(table).count()
    #print(last_index)
    #json_output.insert(0, 'ID', range(last_index, last_index + len(json_output)))
    #json_output.to_sql('iPhoneTradeIn', con = engine, if_exists = 'append', index = False, chunksize = 1000)
   
    #client = boto3.client('lambda', region_name="us-east-2")
    #client.invoke(FunctionName = 'arn:aws:lambda:us-east-2:985716428649:function:awslambda_stop_script', InvocationType = 'Event')

    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }

if __name__=="__main__":
    print(lambdaFunction())
