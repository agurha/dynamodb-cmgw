import json
import boto3
import time

def lambda_handler(event, context):
    # TODO implement
    ec2 = boto3.resource('ec2')
    ec2.Instance('i-00da32dbe057c983b').start() #<-will be the instanceid of the ec2 that you would have set up to run the script
    time.sleep(180)
    command = '/home/ubuntu/gazipscript.sh' #<- this is the location in ec2 instance where the script is located
    ssm = boto3.client('ssm', region_name="us-east-1") #<- may have to use different region_name depending on where you launch the instance
    response = ssm.describe_instance_information(Filters=[{'Key':'InstanceIds','Values':['i-00da32dbe057c983b']}]) #<-values = will be the instanceid of the ec2
    print(response)
    ssmresponse = ssm.send_command(InstanceIds=['i-00da32dbe057c983b'], DocumentName='AWS-RunShellScript', Parameters= { 'commands': [command] } ) #<- same instanceid as above
    print(ssmresponse)  
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
