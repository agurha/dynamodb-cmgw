import json
import boto3

def lambda_handler(event, context):
    # TODO implement
    ec2 = boto3.resource('ec2')
    ec2.Instance('i-00da32dbe057c983b').stop() #<-instance id of the ec2 (see awslambda_start_script.py first for more details about the instance id)
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
