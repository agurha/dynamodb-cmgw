import json
import boto3
import requests
import urllib3
import urllib
import csv
from datetime import datetime
from datetime import timedelta
from io import StringIO
import re
import time
import pandas as pd
from sqlalchemy import create_engine, MetaData, Table, Column, Integer, Float, String
from sqlalchemy.orm import sessionmaker
import dateparser

def getDate(dateString):
    if ',' in dateString:
        dateString = dateString.split(', ')[1];
        dateString = dateString.split(' - ')[0];
        return convertDate(dateString).date()
    elif '-' in dateString:
        dateString = dateString.split(' – ')[0];
        dateString = dateString.split(' - ');
        startDate = convertDate(dateString[0]);
        endDate = convertDate(dateString[1]);
        finalDate = startDate + (endDate - startDate)/3;
        return finalDate.date()
    else :
        dateString = dateString.split(' – ')[0];
        return convertDate(dateString).date()

def convertDate(a):
    a = dateparser.parse(a);
    ct = datetime.now();

    if a.month < ct.month :
        return a.replace(year = ct.year + 1);
    return a

with open('/home/ubuntu/gazip-master/TrackingDataIndia.csv') as fh:
    reader=csv.DictReader(fh,fieldnames=["Code", "Product", "Model","Country","Screen","Capacity","Processor","Color"])
    code = ''
    output = []
    zipFile = pd.read_csv('/home/ubuntu/gazip-master/zipCodesIndia.csv')
    zipCodes = zipFile.apply(lambda x: x.tolist(), axis=1)
    print(zipCodes);
    ct = datetime.now();
    timestamp = datetime.today().isoformat();
    header = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36'}
    for row in reader:
        code = row["Code"]
        if row["Code"]=="Code" or row["Code"]=="":
            continue
        j = 0
        for zipRow in zipCodes:
            deliveryURL="https://www.apple.com/in/shop/delivery-message?parts.0="+code+"%2FA&postalCode="+str(zipRow[0])
            data = []
            print(deliveryURL)
            try:
                resp=requests.get(deliveryURL, headers=header)
                data=resp.json()
            except Exception as e:
                print(e)
                continue;
            #resp=urllib3.PoolManager().request('GET', deliveryURL)
            #print(data)
            if code+'/A' in data["body"]["content"]["deliveryMessage"]:
                deliveryOptionMessages = "NA"
                deliveryDate = "NA"
                convertedDate = "NA"
                try:   
                    deliveryOptionMessages = data["body"]["content"]["deliveryMessage"][code + '/A']["deliveryOptionMessages"][0];
                    deliveryDate = data["body"]["content"]["deliveryMessage"][code + '/A']["deliveryOptions"][0]["date"];
                    if "unavailable" in deliveryOptionMessages:
                        convertedDate = "NA"
                    elif "Today" in deliveryOptionMessages:
                        convertedDate = ct.strftime("%d/%m/%Y");
                    elif "Tomorrow" in deliveryOptionMessages:
                        convertedDate = (ct + timedelta(days=1)).strftime("%d/%m/%Y");
                    else:
                        convertedDate = getDate(deliveryDate).strftime("%d/%m/%Y")
                except Exception as e:
                    print(e)
                    convertedDate = "NA"

                print(convertedDate)
                output.append({'Model': row['Model'], 'Product': row['Product'], 'Code': code, 'Country': zipRow[3], 'County': zipRow[2], 'City': zipRow[1], 'Zip': zipRow[0], 'Screen': row['Screen'], 'Capacity' : row['Capacity'], 'Processor' : row['Processor'], 'Color': row['Color'], 'Delivery Option Messages': deliveryOptionMessages, 'Delivery Date Message': deliveryDate, 'Delivery Date': convertedDate, 'Timestamp': timestamp})
        time.sleep(2)
    #print("********************")

    #create sqlalchemy engine
    #engine = create_engine("mysql+pymysql://{user}:{pw}@database-1.cx7tfzrnpatm.us-east-2.rds.amazonaws.com:3306/{db}"
     #                               .format(user = "admin",
      #                                              pw = "new_password",
       #                                             db = "LeadTimes"))
    json_output = pd.DataFrame(output)
    #json_output.to_sql('LeadTimes', con = engine, if_exists = 'append', index = False, chunksize = 1000)

    bucket_name = "leadtime"
    file_name = "lead_time_India_"+datetime.now().strftime("%y-%m-%d")+".csv"
    lambda_path = "/tmp/" + file_name
    s3_path = file_name

    s3 = boto3.resource("s3")
    csv_buffer = StringIO()
    json_output.to_csv(csv_buffer, encoding='utf-8', index=False)
    s3.Bucket(bucket_name).put_object(Key=s3_path, Body=csv_buffer.getvalue())

    client = boto3.client('lambda', region_name="us-east-2")
