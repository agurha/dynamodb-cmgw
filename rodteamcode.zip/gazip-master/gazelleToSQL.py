from sqlalchemy import create_engine, MetaData, Table, Column, Integer, Float, String
from sqlalchemy.orm import sessionmaker

import pandas as pd

#filename = 'gazelle_iPhone_tradein_prices_2020-05-31T10_26_14.167549.txt';
filename = input();
# print(filename);

timestamp = filename.split('_', 4);
timestamp = timestamp[4];
timestamp = timestamp.split('.t')[0];
print(timestamp);

filepath = '/home/ubuntu/gazip-master'+ filename;
json_output = pd.read_json(filepath)
#timestamp = "2020-05-31T10_26_14.167549";
json_output['timestamp']=timestamp;

from sqlalchemy import create_engine

# create sqlalchemy engine
engine = create_engine("mysql+pymysql://{user}:{pw}@database-1.cx7tfzrnpatm.us-east-2.rds.amazonaws.com:3306/{db}"
                       .format(user="admin",
                               pw="new_password",
                               db="gazelle"))

metadata = MetaData()
table = Table('iPhoneTradeIn', metadata, Column('ID', Integer), Column('name', String), Column('model', String), Column('size', String), Column('network', String), Column('price', Float), Column('timestamp', String))

Session = sessionmaker(bind = engine)
session = Session()
last_index = session.query(table).count()
#print(last_index)

json_output.insert(0, 'ID', range(last_index, last_index + len(json_output)))
json_output.to_sql('iPhoneTradeIn', con = engine, if_exists = 'append', index = False, chunksize = 1000)
