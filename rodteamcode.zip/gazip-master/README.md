# gazip

Architecture

AWS Cloudwatch (start cron)----->triggers_AWS_LAMBDA_Start_script----->Starts EC2 and runs script----->script saved data to S3 and mysql

the EC2 script can self-terminate the EC2 instance after exection. If the script is taking longer than an hour to execute, something likely is going wrong. So the below cloudwatch/lambda script force shutdown the instance after an hour of triggering its start

AWS Cloudwatch (stop cron, after an hour) ----->triggers_AWS_LAMBDA_Stop_script----->Shutdowns the EC2 instance

