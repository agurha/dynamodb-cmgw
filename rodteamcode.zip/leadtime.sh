#!/bin/sh

/usr/bin/python3 /home/ubuntu/gazip-master/LeadTimesGermany.py >>/home/ubuntu/leadtimelogGermany.txt 2>&1
/usr/bin/python3 /home/ubuntu/gazip-master/LeadTimesJapan.py >>/home/ubuntu/leadtimelogJapan.txt 2>&1
/usr/bin/python3 /home/ubuntu/gazip-master/LeadTimesIndia.py >>/home/ubuntu/leadtimelogIndia.txt 2>&1
/usr/bin/python3 /home/ubuntu/gazip-master/LeadTimesFrance.py >>/home/ubuntu/leadtimelogFrance.txt 2>&1
/usr/bin/python3 /home/ubuntu/gazip-master/LeadTimesItaly.py >>/home/ubuntu/leadtimelogItaly.txt 2>&1
/usr/bin/python3 /home/ubuntu/gazip-master/LeadTimesUK.py >>/home/ubuntu/leadtimelogUK.txt 2>&1
