import json
import boto3
import time

def lambda_handler(event, context):
    print("start")
    ec2 = boto3.resource('ec2')
    ec2.Instance('i-05c7a88447548e566').start()
    print('EC2 start.')
    time.sleep(5)
    command = '/home/ubuntu/leadtime.sh'
    print('EC2 start. Code run')
    ssm = boto3.client('ssm', region_name="us-east-2") 
    response = ssm.describe_instance_information(Filters=[{'Key':'InstanceIds','Values':['i-05c7a88447548e566']}]) 
    print(response)
    ssmresponse = ssm.send_command(InstanceIds=['i-05c7a88447548e566'], DocumentName='AWS-RunShellScript', Parameters= { 'commands': [command] } )
    print(ssmresponse) 
    
    time.sleep(5)
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }