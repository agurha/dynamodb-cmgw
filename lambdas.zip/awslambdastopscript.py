import json
import boto3

def lambda_handler(event, context):
    
    ec2 = boto3.resource('ec2')
    ec2.Instance('i-05c7a88447548e566').stop()
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }